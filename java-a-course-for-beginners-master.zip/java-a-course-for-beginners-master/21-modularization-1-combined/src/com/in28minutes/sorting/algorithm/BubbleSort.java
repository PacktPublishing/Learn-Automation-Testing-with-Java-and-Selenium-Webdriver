package com.in28minutes.sorting.algorithm;

import java.util.List;

public class BubbleSort {

	public List<String> sort(List<String> names) {
		return names;
	}

}
