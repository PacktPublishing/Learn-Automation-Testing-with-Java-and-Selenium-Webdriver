package com.in28minutes.tips.access.package2;

import com.in28minutes.tips.access.package1.ClassAccessModifiers;

//public, protected, (default), private
public class ClassAccessModifiersRunnerInOtherPackage {

	public static void main(String[] args) {
		ClassAccessModifiers c = new ClassAccessModifiers();
	}

}
