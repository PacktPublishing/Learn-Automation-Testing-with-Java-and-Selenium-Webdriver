package com.in28minutes.loops;

public class WhileNumberPlayerRunner {
	public static void main(String[] args) {
		WhileNumberPlayer player = new WhileNumberPlayer(27);
		player.printSquaresUptoLimit();
		player.printCubesUptoLimit();
	}
}
