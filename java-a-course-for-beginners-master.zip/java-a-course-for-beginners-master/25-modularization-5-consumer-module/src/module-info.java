module com.in28minutes.consumer {
	requires com.in28minutes.service.provider;
	requires transitive java.logging;
}